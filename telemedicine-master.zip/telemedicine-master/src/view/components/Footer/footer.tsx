import s from "./index.module.scss";

export const Footer = () => {
  return (
    <footer className={s.Footer}>
      <div>footer</div>
    </footer>
  );
};
